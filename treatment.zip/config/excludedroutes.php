<?php 

return [
	'admin.auth.getLogin',
	'admin.auth.postLogin',
	'admin.auth.logout',
	'admin.dashboard.home',
	'admin.permissions.update',
 
	'admin.settings.edit',
	'admin.settings.update',

	'admin.contacts.index',
	'admin.contacts.edit',
	'admin.contacts.update',
	'admin.contacts.view',
	'admin.contacts.show',

  ];
