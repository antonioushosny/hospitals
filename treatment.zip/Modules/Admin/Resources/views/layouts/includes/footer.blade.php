
<footer class="app-footer">
  <div>
    &copy;
    <a
      href="#"
      target="_blank"
      rel="noopener noreferrer"
      className="mx-2"
    >
      <span style="font-size: 12px; letter-spacing: -1px" >
        {{ __('admin::lang.siteTitle') }}
      </span>
      <img
        src={{ asset('backend/img/logo.jpeg') }}
        alt="siteTitle"
        className="img-fluid mx-3 brand-img"
        style="width: 45px"
      />
    </a>
  </div>
</footer>