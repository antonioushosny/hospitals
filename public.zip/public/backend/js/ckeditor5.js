
$('.ckeditor').each(function(i, obj) {
	ClassicEditor
		.create( obj, {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
});